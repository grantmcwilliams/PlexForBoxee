import mc

def cleanString(string):
	return string.encode("utf-8", "replace")